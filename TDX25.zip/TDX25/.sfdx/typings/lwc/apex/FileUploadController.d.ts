declare module "@salesforce/apex/FileUploadController.uploadFile" {
  export default function uploadFile(param: {base64Data: any, fileName: any, recordId: any}): Promise<any>;
}
