import { LightningElement, track } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import uploadFile from '@salesforce/apex/FileUploadController.uploadFile';

export default class PreAuthRequestForm extends LightningElement {
    @track fileData = null;
    @track fileName = '';
    @track filePreviewUrl = null;
    recordId;

    handleFileChange(event) {
        const file = event.target.files[0];
        if (file && file.type === 'application/pdf') {
            const reader = new FileReader();
            reader.onload = () => {
                this.filePreviewUrl = reader.result; // base64 PDF
                const base64 = reader.result.split(',')[1];
                this.fileData = {
                    filename: file.name,
                    base64: base64
                };
                this.fileName = file.name;
            };
            reader.readAsDataURL(file); // convert to base64 + data URI
        } else {
            this.fileData = null;
            this.filePreviewUrl = null;
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Invalid File',
                    message: 'Only PDF files are allowed.',
                    variant: 'error'
                })
            );
        }
    }

    handleRemoveFile() {
        this.fileData = null;
        this.filePreviewUrl = null;
        this.fileName = '';
    }

    handleSubmit(event) {
        if (!this.fileData) {
            event.preventDefault();
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Missing Attachment',
                    message: 'Please attach a PDF file before submitting.',
                    variant: 'error'
                })
            );
        }
    }

    handleSuccess(event) {
        this.recordId = event.detail.id;
        if (this.fileData) {
            uploadFile({
                base64Data: this.fileData.base64,
                fileName: this.fileData.filename,
                recordId: this.recordId
            })
            .then(() => {
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Success',
                        message: 'PreAuth Request Created and File Uploaded!',
                        variant: 'success'
                    })
                );
                this.fileData = null;
                this.filePreviewUrl = null;
                this.fileName = '';
            })
            .catch(error => {
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Upload Failed',
                        message: error.body.message,
                        variant: 'error'
                    })
                );
            });
        }
    }
}